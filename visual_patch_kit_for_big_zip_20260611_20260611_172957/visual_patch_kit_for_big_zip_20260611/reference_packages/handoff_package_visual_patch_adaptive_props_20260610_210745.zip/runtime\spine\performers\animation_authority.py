"""Animation arbitration for PubCast performers."""

from __future__ import annotations

import copy
import time
from typing import Dict, Optional


class AnimationAuthority:
    """Resolves conflicts when multiple systems want to animate the skeleton."""

    LAYERS = {
        "scripted": 100,
        "interaction": 80,
        "mocap": 60,
        "locomotion": 40,
        "default": 0,
    }

    def __init__(self):
        self._animations: Dict[str, Dict[str, Dict]] = {}

    def register_animation(self, performer_id: str, layer: str, skeleton_pose: Dict, priority: Optional[int] = None):
        """Register animation from a system."""

        if layer not in self.LAYERS and priority is None:
            raise ValueError(f"Unknown animation layer without explicit priority: {layer}")
        self._animations.setdefault(performer_id, {})[layer] = {
            "priority": self.LAYERS.get(layer, priority if priority is not None else 0) if priority is None else priority,
            "skeleton_pose": copy.deepcopy(skeleton_pose),
            "timestamp": time.time(),
        }

    def resolve(self, performer_id: str) -> Dict:
        """Get final skeleton pose."""

        layers = self._animations.get(performer_id, {})
        if not layers:
            return {}
        winner = max(layers.values(), key=lambda item: (item["priority"], item["timestamp"]))
        return copy.deepcopy(winner["skeleton_pose"])

    def clear_layer(self, performer_id: str, layer: str):
        """Remove all animations from a layer."""

        layers = self._animations.get(performer_id)
        if not layers:
            return
        layers.pop(layer, None)
        if not layers:
            self._animations.pop(performer_id, None)

